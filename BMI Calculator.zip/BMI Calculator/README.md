# BMI Calculator & Health Tracker

A modern, user-friendly BMI Calculator and Health Tracking System built with Python, featuring a graphical user interface, database storage, and trend visualization.

## Features

- **Modern GUI**: Clean and attractive interface built with Tkinter
- **BMI Calculation**: Accurate BMI calculation using the standard formula
- **BMI Categories**: Automatic classification with color-coded feedback
  - Underweight (BMI < 18.5) - Orange
  - Normal (18.5 - 24.9) - Green
  - Overweight (25 - 29.9) - Orange
  - Obese (BMI >= 30) - Red
- **Multi-User Support**: Track BMI for multiple users
- **Database Storage**: Automatic saving of all calculations to SQLite database
- **Trend Visualization**: View BMI history with interactive line charts
- **Input Validation**: Comprehensive error checking with user-friendly messages

## Requirements

- Python 3.6 or higher
- Tkinter (usually included with Python)
- Matplotlib

## Installation

1. **Clone or download this project**

2. **Install required dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

   Or install matplotlib directly:
   ```bash
   pip install matplotlib
   ```

3. **Run the application**:
   ```bash
   python bmi_calculator.py
   ```

## Usage

1. Enter your name in the "User Name" field
2. Enter your weight in kilograms
3. Enter your height in meters
4. Click "Calculate BMI" to see your result
5. Click "View BMI Trend" to see your BMI history over time

## Database

The application automatically creates an SQLite database named `bmi_records.db` with a table `bmi_records` that stores:
- User Name
- Weight
- Height
- BMI
- BMI Category
- Date and Time of calculation

## BMI Categories Reference

| Category | BMI Range |
|----------|-----------|
| Underweight | < 18.5 |
| Normal | 18.5 - 24.9 |
| Overweight | 25 - 29.9 |
| Obese | >= 30 |

## Technical Details

- **GUI Framework**: Tkinter
- **Database**: SQLite3
- **Visualization**: Matplotlib
- **Language**: Python 3

## Error Handling

The application includes comprehensive error handling for:
- Empty input fields
- Non-numeric values
- Zero or negative values
- Database operations

## License

This project is open source and available for educational purposes.
