"""
Advanced BMI Calculator and Health Tracking System
A GUI application using Tkinter, SQLite3, and Matplotlib
"""

import tkinter as tk
from tkinter import messagebox
import sqlite3
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


def create_database():
    """
    Create the SQLite database and bmi_records table if they don't exist.
    """
    try:
        conn = sqlite3.connect('bmi_records.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bmi_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_name TEXT NOT NULL,
                weight REAL NOT NULL,
                height REAL NOT NULL,
                bmi REAL NOT NULL,
                bmi_category TEXT NOT NULL,
                date_time TEXT NOT NULL
            )
        ''')
        
        conn.commit()
        conn.close()
    except sqlite3.Error as e:
        messagebox.showerror("Database Error", f"Error creating database: {e}")


def get_category(bmi):
    """
    Classify BMI into categories and return the category name and color.
    
    Args:
        bmi (float): The BMI value
        
    Returns:
        tuple: (category_name, color_code)
    """
    if bmi < 18.5:
        return "Underweight", "#FFA500"  # Orange
    elif 18.5 <= bmi <= 24.9:
        return "Normal", "#008000"  # Green
    elif 25 <= bmi <= 29.9:
        return "Overweight", "#FFA500"  # Orange
    else:
        return "Obese", "#FF0000"  # Red


def save_record(user_name, weight, height, bmi, category):
    """
    Save the BMI record to the SQLite database.
    
    Args:
        user_name (str): Name of the user
        weight (float): Weight in kilograms
        height (float): Height in meters
        bmi (float): Calculated BMI value
        category (str): BMI category
    """
    try:
        conn = sqlite3.connect('bmi_records.db')
        cursor = conn.cursor()
        
        date_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        cursor.execute('''
            INSERT INTO bmi_records (user_name, weight, height, bmi, bmi_category, date_time)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_name, weight, height, bmi, category, date_time))
        
        conn.commit()
        conn.close()
    except sqlite3.Error as e:
        messagebox.showerror("Database Error", f"Error saving record: {e}")


def calculate_bmi():
    """
    Calculate BMI based on user input, validate inputs, display results,
    and save the record to the database.
    """
    # Get input values
    user_name = name_entry.get().strip()
    weight_str = weight_entry.get().strip()
    height_str = height_entry.get().strip()
    
    # Input validation
    if not user_name:
        messagebox.showerror("Input Error", "Please enter your name.")
        return
    
    if not weight_str:
        messagebox.showerror("Input Error", "Please enter your weight.")
        return
    
    if not height_str:
        messagebox.showerror("Input Error", "Please enter your height.")
        return
    
    try:
        weight = float(weight_str)
        height = float(height_str)
    except ValueError:
        messagebox.showerror("Input Error", "Weight and height must be numeric values.")
        return
    
    if weight <= 0:
        messagebox.showerror("Input Error", "Weight must be greater than zero.")
        return
    
    if height <= 0:
        messagebox.showerror("Input Error", "Height must be greater than zero.")
        return
    
    # Calculate BMI
    bmi = weight / (height ** 2)
    bmi_rounded = round(bmi, 2)
    
    # Get category and color
    category, color = get_category(bmi_rounded)
    
    # Display result
    result_label.config(text=f"BMI: {bmi_rounded}", fg=color)
    category_label.config(text=f"Category: {category}", fg=color)
    
    # Save to database
    save_record(user_name, weight, height, bmi_rounded, category)
    
    messagebox.showinfo("Success", "BMI calculated and saved successfully!")


def show_trend():
    """
    Display a line chart showing BMI trends for the entered user.
    """
    user_name = name_entry.get().strip()
    
    if not user_name:
        messagebox.showerror("Input Error", "Please enter your name to view trends.")
        return
    
    try:
        conn = sqlite3.connect('bmi_records.db')
        cursor = conn.cursor()
        
        # Retrieve records for the user, ordered by date
        cursor.execute('''
            SELECT date_time, bmi FROM bmi_records 
            WHERE user_name = ? 
            ORDER BY date_time
        ''', (user_name,))
        
        records = cursor.fetchall()
        conn.close()
        
        if not records:
            messagebox.showinfo("No Records", f"No BMI records found for {user_name}.")
            return
        
        # Extract dates and BMI values
        dates = [record[0] for record in records]
        bmis = [record[1] for record in records]
        
        # Create the plot
        plt.figure(figsize=(10, 6))
        plt.plot(dates, bmis, marker='o', linestyle='-', color='blue', linewidth=2, markersize=8)
        plt.title(f"BMI Trend for {user_name}", fontsize=16, fontweight='bold')
        plt.xlabel("Date", fontsize=12)
        plt.ylabel("BMI", fontsize=12)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        # Show the plot
        plt.show()
        
    except sqlite3.Error as e:
        messagebox.showerror("Database Error", f"Error retrieving records: {e}")


def create_gui():
    """
    Create and configure the main GUI window and all widgets.
    """
    global name_entry, weight_entry, height_entry, result_label, category_label
    
    # Create main window
    root = tk.Tk()
    root.title("BMI Calculator & Health Tracker")
    root.geometry("500x450")
    root.configure(bg="#f0f0f0")
    
    # Create main frame with padding
    main_frame = tk.Frame(root, bg="#f0f0f0", padx=20, pady=20)
    main_frame.pack(expand=True, fill='both')
    
    # Title label
    title_label = tk.Label(
        main_frame, 
        text="BMI Calculator & Health Tracker", 
        font=("Arial", 18, "bold"),
        bg="#f0f0f0",
        fg="#333333"
    )
    title_label.pack(pady=(0, 20))
    
    # User Name input
    name_label = tk.Label(main_frame, text="User Name:", font=("Arial", 11), bg="#f0f0f0")
    name_label.pack(anchor='w')
    name_entry = tk.Entry(main_frame, font=("Arial", 11), width=30)
    name_entry.pack(pady=(5, 15))
    
    # Weight input
    weight_label = tk.Label(main_frame, text="Weight (kg):", font=("Arial", 11), bg="#f0f0f0")
    weight_label.pack(anchor='w')
    weight_entry = tk.Entry(main_frame, font=("Arial", 11), width=30)
    weight_entry.pack(pady=(5, 15))
    
    # Height input
    height_label = tk.Label(main_frame, text="Height (m):", font=("Arial", 11), bg="#f0f0f0")
    height_label.pack(anchor='w')
    height_entry = tk.Entry(main_frame, font=("Arial", 11), width=30)
    height_entry.pack(pady=(5, 15))
    
    # Calculate BMI button
    calculate_button = tk.Button(
        main_frame,
        text="Calculate BMI",
        font=("Arial", 12, "bold"),
        bg="#4CAF50",
        fg="white",
        activebackground="#45a049",
        activeforeground="white",
        relief="raised",
        bd=3,
        width=20,
        command=calculate_bmi
    )
    calculate_button.pack(pady=(10, 20))
    
    # View Trend button
    trend_button = tk.Button(
        main_frame,
        text="View BMI Trend",
        font=("Arial", 12, "bold"),
        bg="#2196F3",
        fg="white",
        activebackground="#0b7dda",
        activeforeground="white",
        relief="raised",
        bd=3,
        width=20,
        command=show_trend
    )
    trend_button.pack(pady=(0, 20))
    
    # Result section
    result_frame = tk.Frame(main_frame, bg="#e0e0e0", padx=15, pady=15, relief="sunken", bd=2)
    result_frame.pack(fill='x', pady=(0, 10))
    
    result_label = tk.Label(
        result_frame,
        text="BMI: --",
        font=("Arial", 14, "bold"),
        bg="#e0e0e0",
        fg="#333333"
    )
    result_label.pack()
    
    category_label = tk.Label(
        result_frame,
        text="Category: --",
        font=("Arial", 12),
        bg="#e0e0e0",
        fg="#333333"
    )
    category_label.pack(pady=(5, 0))
    
    return root


def main():
    """
    Main function to initialize the application.
    """
    # Create database
    create_database()
    
    # Create and run GUI
    root = create_gui()
    root.mainloop()


if __name__ == "__main__":
    main()
